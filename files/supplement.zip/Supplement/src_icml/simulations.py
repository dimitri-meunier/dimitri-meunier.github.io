import numpy as np

def sample_spherical(npoints, ndim=3, bias=0, r=1.):
    '''Sample on the unit sphere'''

    vec = np.random.randn(ndim, npoints)
    vec /= np.linalg.norm(vec, axis=0)
    vec = vec.T
    return r*vec+bias

def generate_regression_tasks(mu,T=500, n=100,r=1, noise=0.1):

    
    d = mu.shape[0]
    
    # regression parameters
    coefs = sample_spherical(T,d,bias=mu,r=r)
    
    # inputs
    Xs = np.zeros((T,n,d))
    for t in range(T):
        Xs[t] = sample_spherical(n,d)
        
    # noise
    eps = 2*noise*np.random.uniform(size=(T,n)) - noise
    
    # targets
    ys = np.zeros((T,n))
    for t in range(T):
        ys[t] = Xs[t].dot(coefs[t]) + eps[t]
                
    return Xs, ys, coefs


def generate_classification_tasks(mu,T=500, n=100,r=1, error=0.1):
    
    d = mu.shape[0]
    
    # task parameters
    coefs = sample_spherical(T,d,bias=mu,r=r)
    
    # inputs
    Xs = np.zeros((T,n,d))
    for t in range(T):
        Xs[t] = sample_spherical(n,d)
                
    # targets
    ys = np.zeros((T,n))
    for t in range(T):
        prob = (1+np.exp(-Xs[t].dot(coefs[t])))**(-1)
        ys[t] = 2*(prob>0.5)-1
        
    # random swap of labels
    n_e = int(error*n)
    for t in range(T):
        ys[t,:n_e] = np.random.permutation(ys[t,:n_e])
    for t in range(T):
        perm = np.random.permutation(n)
        Xs[t] = Xs[t][perm]
        ys[t] = ys[t][perm]
        
    return Xs, ys, coefs