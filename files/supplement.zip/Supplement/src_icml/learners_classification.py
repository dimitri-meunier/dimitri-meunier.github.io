import numpy as np 

class OGA():
    """Online Gradient Descent with the hinge loss"""
    
    def __init__(self, lr, adaptive_lr=False):
        
        self.lr = lr
        self.w_list_ = [] # sequence of weights
        self.fitted = False
        self.coef_ = None # final weights
        self.losses_ = [] # sequence of losses
        
    def fit(self,X,y,init=None):    
        
        n,d = X.shape
        
        # init
        if init is None:
            w = np.zeros(d)
        else:
            w = init.copy()
        self.w_list_.append(w.copy()) 
        
        for i in range(n):
            xi = X[i]
            yi = y[i]

            self.losses_.append(self.loss(xi,yi,w))
            g = self.gradient(xi,yi,w)
            w -= self.lr*g
            self.w_list_.append(w.copy())
            
        self.coef_ = w
        self.fitted=True
        
    def loss(self,x,y,t):
        out = 1 - y*x.dot(t)
        if out>0:
            return out
        return 0 

    def gradient(self, x,y,t):
        if y*x.dot(t)<=1:
            return -x*y
        else:
            return 0
            
    def predict(self,X):
        assert self.fitted
        pred = X.dot(self.coef_)
        pred = 2*(pred>0)-1
        return pred
    
    def fit_predict(self,X,y):
        self.fit(X,y)
        return self.predict(X)


class mean_OPMS():
    """Proximal method for meta learning (only the initialisation)"""
    
    def __init__(self, lr, gamma, steps, solver=None):
        
        self.solver = solver    
        self.gamma = gamma   # inner learning rate
        self.lr = lr         # meta learning rate
        self.mu_list_ = []   # sequence of meta means
        self.fitted = False
        self.params_ = None  # final parameters
        self.steps = steps   # Number of steps for the meta optimisation loop
        
    def fit(self,Xs,ys):    
        
        T,n,d = Xs.shape
        mu = np.zeros(d) # meta mean
        self.mu_list_.append(mu.copy())

        for t in range(T):
            X = Xs[t]
            y = ys[t]
            mu = self.solverGD(X,y,mu)
            self.mu_list_.append(mu.copy())
        
        self.params_ = mu.copy()
        self.fitted=True
        
    def solverGD(self,X,y,theta_prev):
        n,d = X.shape
        lr = 0.01
        theta0 = theta_prev.copy()
        theta = theta_prev.copy()
        
        for j in range(self.steps):
            g = np.zeros(d)
            for i in range(n):
                if y[i]*X[i].dot(theta) <= 1:
                    g -= y[i]*X[i]
        
            g_theta = g + (theta - theta0)/self.gamma
            g_theta0 = (theta0 - theta)/self.gamma + (theta0 - theta_prev)/self.lr
            theta -= lr*g_theta
            theta0 -= lr*g_theta0

        return theta0

class OPMS():
    """Proximal method for meta learning with the Hing loss (initialisation and gradient step)"""
    
    def __init__(self, lr, L=1., steps=10):

        self.steps = steps
        self.L = L            # Lipshchitz parameter
        self.lr = lr
        self.mu_list_ = []    # sequence of meta means
        self.gamma_list_ = [] # sequence of meta learned rates
        self.fitted = False
        self.params_ = None   # final parameters
        
    def fit(self,Xs,ys):    
        
        T,n,d = Xs.shape
        mu = np.zeros(d) # meta mean
        gamma = 1/np.sqrt(n)
        self.mu_list_.append(mu.copy())
        self.gamma_list_.append(gamma)

        for t in range(T):
            X = Xs[t]
            y = ys[t]
            mu, gamma = self.solverGD(X, y, mu, gamma)
            self.mu_list_.append(mu.copy())
            self.gamma_list_.append(gamma)
        
        self.params_ = (mu.copy(), gamma)
        self.fitted = True
        
    def solverGD(self,X,y,theta_prev, gamma_prev):
        n,d = X.shape
        lr = 0.01
        theta0 = theta_prev.copy()
        theta = theta_prev.copy()
        gamma = gamma_prev
                
        for j in range(self.steps):
            g = np.zeros(d)
            for i in range(n):
                if y[i]*X[i].dot(theta) <= 1:
                    g -= y[i]*X[i]
            
            g_theta = g + (theta - theta0)/gamma_prev
            g_theta0 = (theta0 - theta)/gamma + (theta0 - theta_prev)/self.lr
            g_gamma = self.L*n/2 - np.sum( (theta - theta0)**2  ) / gamma**2 + (gamma - gamma_prev)/self.lr
            
            theta -= lr*g_theta
            theta0 -= lr*g_theta0
            gamma -= lr*g_gamma
            
            beta = 0.5
            c = 1.
            if gamma  <= c*n**(-beta):
                gamma = c*n**(-beta)
            
        return theta0, gamma
