import numpy as np 

class OGA_reg():
    """Online Gradient Descent for linear regression"""
    
    def __init__(self, lr):
        
        self.lr = lr      # learning rate
        self.w_list_ = [] # sequence of weights
        self.fitted = False
        self.coef_ = None # final weights
        self.losses_ = [] # sequence of losses
        
    def fit(self,X,y,init=None): 
        # use init to specify the initialisation
        
        n,d = X.shape
        
        if init is None:
            w = np.zeros(d)
        else:
            w = init.copy()
        self.w_list_.append(w.copy()) 
        
        for i in range(n):

            xi = X[i]
            yi = y[i]

            self.losses_.append(self.loss(xi,yi,w))
            g = self.gradient(xi,yi,w)
            w -= self.lr*g

            self.w_list_.append(w.copy())
            
        self.coef_ = w
        self.fitted=True
        
    def loss(self,x,y,t):
        return (y - x.dot(t))**2

    def gradient(self, x,y,t):
        return 2*x*(x.dot(t) - y)
            
    def predict(self,X):
        assert self.fitted
        return X.dot(self.coef_)
    
    def fit_predict(self,X,y):
        self.fit(X,y)
        return self.predict(X)



class mean_OGMS():
    """mean-OGMS for linear regression (explicit meta gradient)
    Only learns the meta mean"""
    
    def __init__(self, lr, gamma):
        
        self.gamma = gamma   # inner learning rate
        self.lr = lr         # meta learning rate
        self.mu_list_ = []   # store path of meta means
        self.fitted = False
        self.params_ = None  # store final parameters
        
    def fit(self,Xs,ys):   
        
        T,n,d = Xs.shape
        
        mu = np.zeros(d)
        self.mu_list_.append(mu.copy())

        for t in range(T):

            X = Xs[t]
            Y = ys[t]
            mu -= self.lr*self.meta_gradient_mean(X,Y,mu)
            self.mu_list_.append(mu.copy())
            
        self.params_ = mu.copy()
        self.fitted=True
            
    def meta_gradient_mean(self,X,Y,m):
        '''Explicit Meta gradient update'''
        d = X.shape[-1]

        XY = X.T.dot(Y)
        G = X.T.dot(X)
        G_gamma_inv = np.linalg.inv(G + np.eye(d)/(2*self.gamma))
        g1 = G_gamma_inv.dot( G.dot(G_gamma_inv).dot( m/(2*self.gamma) + XY ) - XY)
        g2 = G.dot(G_gamma_inv.dot(G_gamma_inv)).dot(G.dot(m) - XY)
        gm = (g1 + g2)/self.gamma
        
        return gm



class mean_OPMS():
    """mean-OPMS for linear regression (proximal update), only learns the mean"""
    
    def __init__(self, lr, gamma):
         
        self.gamma = gamma   # inner learning rate
        self.lr = lr         # meta learning rate
        self.mu_list_ = []   # sequence of meta means
        self.fitted = False
        self.params_ = None  # final parameters
        
    def fit(self,Xs,ys):    
        
        T,n,d = Xs.shape
        mu = np.zeros(d) 
        self.mu_list_.append(mu.copy())

        for t in range(T):
            X = Xs[t]
            y = ys[t]
            mu = self.solverNewton(X,y,mu)
            self.mu_list_.append(mu.copy())
        
        self.params_ = mu.copy()
        self.fitted=True
            
    def solverNewton(self,X,y,theta_prev):
        d = X.shape[-1]
        
        F11 = 2*X.T.dot(X) + np.eye(d)/self.gamma
        F = np.zeros((2*d,2*d))
        F[:d,:d] = F11
        F[d:,d:] = np.eye(d)*( 1/self.gamma + 1/self.lr )
        F[:d,d:] = -np.eye(d)/self.gamma
        F[d:,:d] = -np.eye(d)/self.gamma
        
        # Initialisation
        theta0 = theta_prev.copy()
        theta = theta_prev.copy()
        
        for i in range(3):
            g_theta = -2*X.T.dot(y) + 2*X.T.dot(X).dot(theta) + (theta - theta0)/self.gamma
            g_theta0 = (theta0 - theta)/self.gamma + (theta0 - theta_prev)/self.lr    
            g = np.linalg.inv(F).dot(np.concatenate((g_theta,g_theta0)))
            theta -= g[:d]
            theta0 -= g[d:]

        return theta0



class OPMS():
    """Proximal method for meta learning on regression tasks"""
    
    def __init__(self, lr, solver="newton", L=1., steps=10):

        self.steps = steps
        self.solver = self.solverNewton if solver=="newton" else self.solverGD
        self.L = L            # Lipshchitz parameter
        self.lr = lr
        self.mu_list_ = []    # sequence of meta means
        self.gamma_list_ = [] # sequence of meta learned rates
        self.fitted = False
        self.params_ = None   # final parameters
        
    def fit(self,Xs,ys):    
        
        T,n,d = Xs.shape
        mu = np.zeros(d) 
        gamma = 1/np.sqrt(n)
        self.mu_list_.append(mu.copy())
        self.gamma_list_.append(gamma)

        for t in range(T):
            X = Xs[t]
            y = ys[t]
            mu, gamma = self.solver(X, y, mu, gamma)
        
            self.mu_list_.append(mu.copy())
            self.gamma_list_.append(gamma)
            
        self.params_ = (mu.copy(), gamma)
        self.fitted=True
        
    def solverGD(self,X,y,theta_prev, gamma_prev):
        lr = 0.01
        theta0 = theta_prev.copy()
        theta = theta_prev.copy()
        gamma = gamma_prev
        
        for i in range(self.steps):
            g_theta = -2*X.T.dot(y) + 2*X.T.dot(X).dot(theta) + (theta - theta0)/gamma
            g_theta0 = (theta0 - theta)/gamma + (theta0 - theta_prev)/self.lr
            g_gamma = self.L*n/2 - np.sum( (theta - theta0)**2  ) / gamma**2 + (gamma - gamma_prev)/self.lr
            theta -= lr*g_theta
            theta0 -= lr*g_theta0
            gamma -= lr*gamma
            if gamma <=n**(-1):
                gamma = n**(-1)

        return theta0, gamma
            
    def solverNewton(self,X,y,theta_prev, gamma_prev):
        
        n,d = X.shape
        
        # Initialisation
        theta0 = theta_prev.copy() 
        theta = theta_prev.copy() 
        gamma = gamma_prev
        
        for i in range(self.steps):
               
            # Newton preconditioner
            F11 = 2*X.T.dot(X) + np.eye(d)/gamma
            F = np.zeros((2*d+1 ,2*d+1))
            F[:d,:d] = F11
            F[d:2*d,d:2*d] = np.eye(d)*( 1/gamma + 1/self.lr )
            F[:d,d:2*d] = -np.eye(d)/gamma
            F[d:2*d,:d] = -np.eye(d)/gamma
            F[:d,-1] = (theta0 - theta) / gamma**2
            F[d:2*d,-1] = (theta - theta0) / gamma**2
            F[-1,:d] = (theta0 - theta) / gamma**2
            F[-1,d:d*2] = (theta - theta0) / gamma**2
            F[-1,-1] = np.sum( (theta - theta0)**2  ) / gamma**3 + 1/self.lr
            
            # Gradients
            g_theta = -2*X.T.dot(y) + 2*X.T.dot(X).dot(theta) + (theta - theta0)/gamma
            g_theta0 = (theta0 - theta)/gamma + (theta0 - theta_prev)/self.lr 
            g_gamma = self.L*n/2 - np.sum( (theta - theta0)**2  ) / gamma**2 + (gamma - gamma_prev)/self.lr
            
            # Newton update
            g = np.linalg.inv(F).dot(np.concatenate((g_theta,g_theta0, np.array([g_gamma]) )))
            theta -= g[:d]
            theta0 -= g[d:2*d]
            gamma -= g[-1]
            
            if gamma <=n**(-1):
                gamma = n**(-1)
    
        return theta0, gamma